# GTX_FIX v0.1DEMO

GTX_FIX resolves the incompatibility issue between GTX 1060-3GB and some other Pascal-based NVIDIA GPUs with Windows 9x and Windows for Workgroups 3.11.

## Problem Description  
When installing Windows on PC equipped with GTX 1060-3GB, the system fails to boot after the first restart.

## DEMO limitations
- Does not include patch code for fixing DOS VM sessions issues.
- Does not support Windows for Workgroups 3.11 and Windows 95. 
- Command-line arguments for custom patch functionality are not supported.

## Supported Configurations  
- Windows 98 SE (tested with US Retail release)

## Requirements
- Windows 98 SE is installed in `C:\WINDOWS`
- (optional, but highly recommended) Back up all important data before applying the patch

## Usage  
- Run `gtx_fix.exe` from DOS on the affected system.
- Apply this patch after the first restart during Windows 98 SE installation to ensure the next stage boots successfully.
- No additional configuration or arguments are required for this version - v0.1DEMOs patch is fully automatic.  

## Limitations  
- This patch addresses only the GTX-specific issue described above.  
- Additional steps may be required to run Windows 98 SE on modern platforms.  

## Disclaimer  
This software is provided "as is." Do not use on critical systems. Always back up important data before use.  

Enjoy your retro computing!  

crt0 2025, https://dsoemu.pages.dev
