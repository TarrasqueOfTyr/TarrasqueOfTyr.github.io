Dark Sun Online: Crimson Sands Windows port based on SDL2

This build (based on v0.6) includes an experimental Single-player mode for a full offline playthrough without an internet connection or servers.

The project is in alpha, so bugs are possible (and there will be some, no doubt).

ABOUT:

No AI was used in this project, everything was done with my own brains, hands, and experience.
That is why an old-as-time HLE approach was used: the loader loads the original game blob into memory (yes, you have to provide the original mdark.exe v2.8 and all the game data files) and patches all platform-dependent calls to a high-level wrapper (modern winapi and SDL2).
Instead of spending years manually reversing all the thousands of game functions (including the game logic and gamescript vm interpreter), only the low-level system boundaries were located and hooked: clib/stdlib calls and file I/O, win16 dusty apis, dos interrupts, 1Mb segment access, vga segment and ports - all wrapped onto modern winapi and SDL2 abstraction.

Cons of this approach:
- Such actions (specifically, setting RWX permissions on virtual memory segments, runtime inline hooks and patches, and subsequently executing the original game code loaded into a segment) trigger almost all antivirus software - so the port requires disabling your antivirus or adding it to exclusions, otherwise no miracle will happen.
- The port is nailed down tight to the x86-32 architecture (which is not an issue at this stage).

Pros of this approach:
- For those who care about this - you can be sure that the entire port, including its general architecture, was written the old-fashioned way by a meatbag. No AI slop, though... humans make mistakes too, so bugs are definitely present, as well as possibly suboptimal solutions. Still, everything in this port, from the first line to the last, was written by a human by hand and with full awareness. Smash that like button if you get an uncanny valley feeling looking at the flood of AI-slop ports! :)
- The HLE code is small and optimized.
- HLE does not interfere with the original logic. All core algorithms are original, no assumptions, guesses, or simulations. Fidelity, so to speak. Including the bugs generously scattered by the original developers. Just like in the good old days :)
- It does not require spending tons of time on routine work like disassembling ALL of the original game code, since it is used directly in its original form.

HOW TO PLAY:

The port requires the original files and executable from the last official release of the Dark Sun Online: Crimson Sands client (so-called version "2.8", build tag "2.0:Sep 05 1997:12:07:23").

Original hashes for vanilla v2.8 Mdark.exe:
MD5 c933508e291bb3ebfcc276344bdfd6ef
SHA256 d04ef090951cd2d3e51dc750f9eb024cfc57e902a6ad0f8763b89129ddc2bef7

Hashes for this v0.6 port build (dso-win.exe):
MD5 1fec259273b8c863ae4f0cc67dede59b
SHA256 4922ae953e3ccbfd095287a237c1c839712f535bb464b73c998c2d7a5e86c0ad

Put all the port files (dso-win.exe, SDL2.dll, SDL2_mixer.dll, the "cdaudio" folder) into your DSO v2.8 directory and run dso-win.exe - don't forget to add the folder to your ANTIVIRUS EXCLUSIONS beforehand or disable your antivirus while playing.

The port supports the original game's CD-Audio feature: to use it, place the ogg files named "track02.ogg .. track29.ogg" into the "cdaudio" subfolder.

Basic controls:
Middle mouse - capture/release mouse cursor
F12 - toggle standard SDL2 bilinear filtering
Alt+Enter - toggle Fullscreen
Shift - skip the intro cinematic
S, C, E - main menu shortcuts: Start game, Create character, Exit
Alt+P - in-game settings during gameplay
F1 - show in-game help
F6, Alt+A - toggle character animations
1..9 - select dialog options with NPCs or during events

USEFUL LINKS:

Original manual: https://mocagh.org/ssi/darksunonline-manual.pdf
Original FAQ by AVrignaud: https://gamefaqs.gamespot.com/pc/565241-dark-sun-online-crimson-sands/faqs/2245

- crt0, 2024-2026
https://dsoemu.pages.dev
https://discord.gg/TDyzXXj4Pd
